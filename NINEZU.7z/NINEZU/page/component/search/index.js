// page/component/search/index.js
Page({

  /**
   * Page initial data
   */
  data: {
    showResult: false,
    value: '',
    result:[]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  },
  doSearch: function () {
    if(this.data.value.trim()=='')return
    var _that=this
    const db = wx.cloud.database();
    const $ = db.command.aggregate
    db.collection('data1').aggregate().match({
      mark:'goods'
    }).project({
      'data': $.filter({
        input: '$data',
        as: 'item',
        cond: 
        $.neq([$.indexOfCP(['$$item.title',_that.data.value]),-1])
        //$.eq(['$$item.title',"夏季女上衣"])
      })
    }).end().then(res=>{
      _that.setData({
        result:res.list[0].data,
        showResult: true
      })
    })
  }
})