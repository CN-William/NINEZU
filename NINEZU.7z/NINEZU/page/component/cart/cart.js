// page/component/new-pages/cart/cart.js
Page({
  data: {
    carts:[],               // 购物车列表
    hasList:false,          // 列表是否有数据
    totalPrice:0,           // 总价，初始为0
    selectAllStatus:true,    // 全选状态，默认全选
    obj:{
        name:"hello"
    }
  },
  onShow() {
    var arr = wx.getStorageSync('cart') || [];
    //与数据库中数据对比
    const db = wx.cloud.database();
    // 查询当前用户所有的 counters
    db.collection('data1').where({
      mark: "goods"
    }).get({
      success:res=>{
        let _goodsInDb=res.data[0].data
        outl:for(var i=0;i<arr.length;i++){
              for(var j=0;i<_goodsInDb.length;j++){
                if(parseInt(arr[i].id)==parseInt(_goodsInDb[j].id)){
                  continue outl;
                }
              }
              arr.splice(i,1);
        }
        wx.setStorageSync('cart', arr)
      }
    })
    for (var index in arr) {
      arr[index].selected = true
    }  
    this.setData({
      carts: arr
    });
    this.getTotalPrice();
    if (arr.length > 0){
      this.setData({
        hasList: true,
      });      
    }

  },
  /**
   * 当前商品选中事件
   */
  selectList(e) {
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    const selected = carts[index].selected;
    carts[index].selected = !selected;
    this.setData({
      carts: carts
    });
    this.getTotalPrice();
  },

  /**
   * 删除购物车当前商品
   */
  deleteList(e) {
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    carts.splice(index,1);
    this.setData({
      carts: carts
    });
    wx.setStorageSync('cart', carts)
    if(!carts.length){
      this.setData({
        hasList: false
      });
    }else{
      this.getTotalPrice();
    }
  },

  /**
   * 购物车全选事件
   */
  selectAll(e) {
    let selectAllStatus = this.data.selectAllStatus;
    selectAllStatus = !selectAllStatus;
    let carts = this.data.carts;

    for (let i = 0; i < carts.length; i++) {
      carts[i].selected = selectAllStatus;
    }
    this.setData({
      selectAllStatus: selectAllStatus,
      carts: carts
    });
    this.getTotalPrice();
  },

  /**
   * 绑定加数量事件
   */
  addCount(e) {
    const index = e.currentTarget.dataset.index;
    let carts = this.data.carts;
    let count = carts[index].count;
    count = count + 1;
    carts[index].count = count;
    this.setData({
      carts: carts
    });
    this.getTotalPrice();
    wx.setStorageSync('cart', carts)
  },

  /**
   * 绑定减数量事件
   */
  minusCount(e) {
    const index = e.currentTarget.dataset.index;
    const obj = e.currentTarget.dataset.obj;
    let carts = this.data.carts;
    let count = carts[index].count;
    if (count <= 1){
      return false;
    }
    count = count - 1;
    carts[index].count = count;
    this.setData({
      carts: carts
    });
    this.getTotalPrice();
    wx.setStorageSync('cart', carts)
  },
 
  /**
   * 计算总价
   */
  getTotalPrice() {
    let carts = this.data.carts;                  // 获取购物车列表
    let total = 0;
    for(let i = 0; i<carts.length; i++) {         // 循环列表得到每个数据
      if(carts[i].selected) {                     // 判断选中才会计算价格
        total += carts[i].count * carts[i].price;   // 所有价格加起来
      }
    }
    this.setData({                                // 最后赋值到data中渲染到页面
      carts: carts,
      totalPrice: total.toFixed(2)
    });
  },
  saveOder(e) {
    var oder = [];
    for (var index in this.data.carts){
      if (this.data.carts[index].selected){
        oder.push(this.data.carts[index])
      } 
    }
    var openid = getApp().globalData.openid;
    wx.setStorageSync('tempOder', oder)
    wx.navigateTo({
      url: "../orders/orders?openid=" + openid
    });    
  } 

}) 